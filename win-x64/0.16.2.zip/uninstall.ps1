$serviceName = "AutoCertify"

if (Get-Service -Name $serviceName -ErrorAction SilentlyContinue)
{
    Stop-Service -Name $serviceName -Force
    Write-Host "已停止 $serviceName 服务" -ForegroundColor Yellow

    Remove-Service -Name $serviceName
    Write-Host "已卸载 $serviceName 服务" -ForegroundColor Yellow
}
