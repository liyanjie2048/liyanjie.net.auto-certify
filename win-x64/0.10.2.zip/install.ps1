$dotnetHostingBundle = "Microsoft.DotNet.HostingBundle.10"
$serviceName = "AutoCertify"

function Install-DotNetHostingBundle
{
    if (winget list --id $dotnetHostingBundle --exact 2>&1 | Select-String -Pattern $dotnetHostingBundle)
    {
        Write-Host "$dotnetHostingBundle 已安装，跳过。" -ForegroundColor Green
    }
    else
    {
        Write-Host "正在安装 $dotnetHostingBundle ..." -ForegroundColor Yellow
        winget install --id $dotnetHostingBundle `
            --accept-package-agreements `
            --accept-source-agreements
    }
}
function Install-AutoCertify
{
    $exeFile = if ($IsWindows)
    {
        ".\AutoCertify.exe"
    }
    else
    {
        Write-Error "暂不支持非 Windows 平台"
        exit 1
    }
    $exePath = Join-Path $PSScriptRoot $exeFile

    if (!(Test-Path $exePath))
    {
        Write-Error "找不到文件 $exeFile"
        exit 1
    }

    Get-Service $serviceName -ErrorAction SilentlyContinue
    if ($?)
    {
        Stop-Service -Name $serviceName -Force
        Write-Host "已停止 $serviceName 服务" -ForegroundColor Yellow

        Remove-Service -Name $serviceName
        Write-Host "已卸载 $serviceName 服务" -ForegroundColor Yellow
    }

    New-Service -Name $serviceName `
            -BinaryPathName $exePath `
            -StartupType AutomaticDelayedStart `
            -DisplayName $serviceName `
            -Description "AutoCertify丨自动化证书申请与部署"
    Write-Host "已安装 $serviceName 服务" -ForegroundColor Green
}
function Start-AutoCertify
{
    Start-Service -Name $serviceName
    Write-Host "已启动 $serviceName 服务" -ForegroundColor Green

    Start-Process "http://localhost:17443"
}
function Wait-ForExit
{
    $seconds = 10
    Write-Host "将在 $seconds 秒后自动退出，按任意键立即退出..." -ForegroundColor Yellow

    $startTime = Get-Date

    while (((Get-Date) - $startTime).TotalSeconds -lt $seconds)
    {
        $remainSeconds = [math]::Round($seconds - ((Get-Date) - $startTime).TotalSeconds)
        Write-Host "`e[1A`e[K将在 $remainSeconds 秒后自动退出，按任意键立即退出..." -ForegroundColor Yellow

        if ([Console]::KeyAvailable)
        {
            $null = [Console]::ReadKey($true)
            break
        }

        Start-Sleep -m 1000
    }
}

Install-DotNetHostingBundle
Install-AutoCertify
Start-AutoCertify
Wait-ForExit
