$serviceName = "AutoCertify"

Get-Service $serviceName -ErrorAction SilentlyContinue
if ($?)
{
    Stop-Service -Name $serviceName -Force
    Write-Host "已停止AutoCertify服务" -ForegroundColor Yellow

    Remove-Service -Name $serviceName
    Write-Host "已卸载AutoCertify服务" -ForegroundColor Yellow
}
