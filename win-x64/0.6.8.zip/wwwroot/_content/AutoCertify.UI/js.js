const
    reconnectModal = document.getElementById("components-reconnect-modal"),
    reloadButton = document.getElementById("components-reconnect-button-reload"),
    resumeButton = document.getElementById("components-reconnect-button-resume");

reconnectModal.addEventListener("components-reconnect-state-changed", handleReconnectStateChanged);
reloadButton.addEventListener("click", reload);
resumeButton.addEventListener("click", resume);

function handleReconnectStateChanged(event) {
    if (event.detail.state === "show") {
        reconnectModal.showModal();
    } else if (event.detail.state === "hide") {
        reconnectModal.close();
    } else if (event.detail.state === "failed") {
        document.addEventListener("visibilitychange", reloadWhenDocumentBecomesVisible);
    } else if (event.detail.state === "rejected") {
        setTimeout(() => location.reload(), 1000);
    }
}

async function reload() {
    document.removeEventListener("visibilitychange", reloadWhenDocumentBecomesVisible);

    try {
        // Reconnect will asynchronously return:
        // - true to mean success
        // - false to mean we reached the server, but it rejected the connection (e.g., unknown circuit ID)
        // - exception to mean we didn't reach the server (this can be sync or async)
        const reconnectSuccessful = await Blazor.reconnect();
        if (!reconnectSuccessful) {
            // We have been able to reach the server, but the circuit is no longer available.
            // We'll reload the page so the user can continue using the app as quickly as possible.
            const resumeSuccessful = await Blazor.resumeCircuit();
            if (!resumeSuccessful) {
                location.reload();
            } else {
                reconnectModal.close();
            }
        }
    } catch (err) {
        // We got an exception, server is currently unavailable
        document.addEventListener("visibilitychange", reloadWhenDocumentBecomesVisible);
    }
}

async function resume() {
    try {
        const successful = await Blazor.resumeCircuit();
        if (!successful) {
            location.reload();
        }
    } catch {
        reconnectModal.classList.replace("components-reconnect-paused", "components-reconnect-failed");
    }
}

async function reloadWhenDocumentBecomesVisible() {
    if (document.visibilityState === "visible") {
        await reload();
    }
}
