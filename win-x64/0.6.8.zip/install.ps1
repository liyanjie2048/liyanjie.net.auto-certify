$serviceName = "AutoCertify"
$exeFile = if ($IsWindows) {
    "AutoCertify.exe"
} elseif ($IsLinux) {
    "UNKNOWN"
} elseif ($IsMacOS) {
    "UNKNOWN"
} else {
    "UNKNOWN"
}
$exePath = Join-Path $PSScriptRoot $exeFile

if (!(Test-Path $exePath)) {
    Write-Error "Cannot find $exeFile"
    exit 1
}

New-Service -Name $serviceName `
            -BinaryPathName $exePath `
            -StartupType AutomaticDelayedStart `
            -DisplayName "AutoCertify" `
            -Description "AutoCertify丨自动化证书申请与部署"
Write-Host "已安装AutoCertify服务" -ForegroundColor Green
# 确保服务已启动
Start-Service -Name $serviceName
Write-Host "已启动AutoCertify服务" -ForegroundColor Green
Start-Process "http://localhost:17443"